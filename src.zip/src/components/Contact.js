export default function Contact() {
  return (
    <section id="contact" className="container my-5 fade-in text-center">
      <h2 className="fw-bold mb-4">Contact</h2>
      <p>Email : <strong>samira.dev@gmail.com</strong></p>

      <div className="mt-3">
        <a href="https://github.com/samira" className="btn btn-outline-dark mx-2">GitHub</a>
        <a href="https://linkedin.com/in/samira" className="btn btn-outline-primary mx-2">LinkedIn</a>
      </div>
    </section>
  );
}
