import React from "react";
import { FaGithub, FaLinkedin, FaEnvelope, FaWhatsapp } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="footer-pro mt-5">
      <div className="container text-center py-5">

        {/* ✅ LOGO / NAME */}
        <h4 className="fw-bold mb-2">
          Sami <span className="text-gradient">Aboutarik</span>
        </h4>

        {/* ✅ DESCRIPTION */}
        <p className="text-muted small mb-4">
          Full-Stack Developer • React • Laravel • MySQL
        </p>

        {/* ✅ SOCIAL ICONS */}
        <div className="footer-social-pro d-flex justify-content-center gap-4 mb-4">
          <a href="https://github.com/" target="_blank" rel="noreferrer">
            <FaGithub />
          </a>

          <a href="https://linkedin.com/" target="_blank" rel="noreferrer">
            <FaLinkedin />
          </a>

          <a href="mailto:your.email@gmail.com">
            <FaEnvelope />
          </a>

          <a href="https://wa.me/212600000000" target="_blank" rel="noreferrer">
            <FaWhatsapp />
          </a>
        </div>

        {/* ✅ DIVIDER */}
        <div className="footer-divider mb-3"></div>

        {/* ✅ COPYRIGHT */}
        <p className="small text-muted mb-0">
          © {new Date().getFullYear()} All Rights Reserved | Designed by Sami
        </p>

      </div>
    </footer>
  );
}
