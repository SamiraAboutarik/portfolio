import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { FiSun, FiMoon } from "react-icons/fi";

export default function Navbar({ darkMode, toggleDarkMode }) {
  const location = useLocation();
  const [active, setActive] = useState("/");

  useEffect(() => {
    setActive(location.pathname);
  }, [location]);

  return (
    <nav className={`pro-navbar ${darkMode ? "dark" : ""}`}>
      <div className="nav-container">

        {/* ✅ LOGO */}
        <Link to="/" className="nav-logo">
          SA<span>MIRA</span>
        </Link>

        {/* ✅ LINKS */}
        <div className="nav-links">
          <Link to="/" className={active === "/" ? "active" : ""}>
            Home
          </Link>

          <Link to="/projects" className={active === "/projects" ? "active" : ""}>
            Projects
          </Link>

          <Link to="/contact" className={active === "/contact" ? "active" : ""}>
            Contact
          </Link>
        </div>

        {/* ✅ DARK MODE BUTTON */}
        <button className="theme-btn" onClick={toggleDarkMode}>
          {darkMode ? <FiSun /> : <FiMoon />}
        </button>

      </div>
    </nav>
  );
}
